import { ArtistPage } from '@/components/pipa-arte/artist-page';
import { LanguageProvider } from '@/context/language-context';

export default function Home() {
  return (
    <LanguageProvider>
      <ArtistPage />
    </LanguageProvider>
  );
}
