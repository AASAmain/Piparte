'use client';

import { ArrowLeft, Clapperboard, Image as ImageIcon, Music, Users } from 'lucide-react';
import Link from 'next/link';
import Image from 'next/image';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardFooter, CardHeader } from '@/components/ui/card';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Badge } from '@/components/ui/badge';
import { Separator } from '@/components/ui/separator';

const MuralPost = ({
  artistName,
  artistAvatar,
  postTime,
  children,
}: {
  artistName: string;
  artistAvatar: string;
  postTime: string;
  children: React.ReactNode;
}) => (
  <Card className="rounded-2xl overflow-hidden shadow-lg border-none w-full">
    <CardHeader className="flex flex-row items-center gap-3 p-4">
      <Avatar>
        <AvatarImage src={artistAvatar} alt={artistName} />
        <AvatarFallback>{artistName.charAt(0)}</AvatarFallback>
      </Avatar>
      <div className="flex flex-col">
        <span className="font-semibold text-primary">{artistName}</span>
        <span className="text-xs text-muted-foreground">{postTime}</span>
      </div>
    </CardHeader>
    <CardContent className="p-4 pt-0">{children}</CardContent>
    <CardFooter className="bg-gray-50/50 p-2 px-4 border-t">
      <div className="flex gap-4 text-sm text-muted-foreground">
        <button className="hover:text-primary transition-colors">❤️ Like</button>
        <button className="hover:text-primary transition-colors">💬 Comment</button>
      </div>
    </CardFooter>
  </Card>
);

export default function MuralPage() {
  return (
    <div className="min-h-screen bg-background text-foreground">
      <header className="bg-[linear-gradient(135deg,_#3D5A80,_#4ca1af)] text-white p-4 flex items-center justify-between sticky top-0 z-20 shadow-md">
        <Link href="/" passHref>
          <Button variant="ghost" className="text-white hover:bg-white/20">
            <ArrowLeft className="mr-2 h-5 w-5" />
            Voltar
          </Button>
        </Link>
        <h1 className="font-headline text-2xl font-semibold text-center">Mural da Pipa</h1>
        <div className="w-20"></div>
      </header>

      <main className="p-4 md:p-8 max-w-3xl mx-auto">
        <div className="text-center mb-8 p-4 bg-yellow-100/50 border border-yellow-300/60 rounded-xl text-yellow-800">
          <h2 className="font-bold text-lg">🚧 Em Construção 🚧</h2>
          <p className="text-sm">
            O Mural da Pipa será um espaço aberto para artistas compartilharem suas criações, eventos e inspirações. Veja abaixo uma prévia do que está por vir!
          </p>
        </div>

        <div className="space-y-8">
          {/* Post 1: Painting */}
          <MuralPost
            artistName="Artista de Exemplo 1"
            artistAvatar="https://i.ibb.co/C5LhnQcw/IMG-9549.jpg"
            postTime="2 horas atrás"
          >
            <p className="mb-4 text-gray-700">
              Nova tela finalizada! O que acharam? 🎨
            </p>
            <div className="relative aspect-square w-full rounded-lg overflow-hidden border">
              <Image
                src="https://picsum.photos/seed/painting1/600/600"
                alt="Pintura abstrata colorida"
                fill
                className="object-cover"
                data-ai-hint="abstract painting"
              />
            </div>
          </MuralPost>

          {/* Post 2: Music */}
          <MuralPost
            artistName="Musicista da Pipa"
            artistAvatar="https://i.ibb.co/kVYgZRW7/IMG-9536.jpg"
            postTime="Ontem às 18:30"
          >
            <p className="mb-4 text-gray-700">
              Som novo na área! ✨ Para ouvir, clica no link:
            </p>
            <div className="flex items-center gap-4 p-4 border rounded-lg bg-gray-50 hover:bg-gray-100 transition-colors">
              <div className="w-16 h-16 bg-gray-200 rounded-md flex-shrink-0 flex items-center justify-center">
                 <Music className="w-8 h-8 text-gray-500" />
              </div>
              <div className="flex-grow">
                <p className="font-semibold">Bossa Nova da Maré</p>
                <p className="text-sm text-muted-foreground">Single by Musicista da Pipa</p>
              </div>
               <a href="#" className="bg-[#1DB954] text-white rounded-full px-4 py-2 text-sm font-semibold hover:bg-green-600 transition-colors">
                Ouvir
              </a>
            </div>
          </MuralPost>
          
          {/* Post 3: Event */}
          <MuralPost
            artistName="Coletivo de Artistas"
            artistAvatar="https://i.ibb.co/nNsVZdkV/IMG-9542.jpg"
            postTime="3 dias atrás"
          >
             <p className="mb-4 text-gray-700">
              Save the date! Próximo encontro de arte e música ao vivo.
            </p>
            <div className="border rounded-lg overflow-hidden">
                <div className="bg-blue-100 p-6 flex justify-center items-center">
                    <Clapperboard className="w-16 h-16 text-primary/70"/>
                </div>
                <div className="p-4 bg-white">
                    <h4 className="font-bold text-lg text-primary">Sarau no Beco</h4>
                    <p className="text-sm text-muted-foreground">Sábado, 28 de Setembro, às 19:00</p>
                    <Separator className="my-2"/>
                    <p className="text-sm">📍 Local: Beco Beija Flor</p>
                </div>
            </div>
          </MuralPost>

        </div>
      </main>
    </div>
  );
}
