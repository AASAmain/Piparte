export interface Artist {
  id?: string;
  name: string;
  instagramTag?: string;
  category?: "Audiovisual" | "Artesanato" | "Música" | "Roupas" | "Tatuagem" | "Artes Visuais" | "Performance" | "Gastronomia" | "Espaços";
  subCategories?: string[];
  description?: string;
  imageUrl?: string;
  instagramLink?: string;
  portfolioLink?: string;
  youtubeLink?: string;
  spotifyLink?: string;
}

export type Category = "Audiovisual" | "Artesanato" | "Música" | "Roupas" | "Tatuagem" | "Artes Visuais" | "Performance" | "Gastronomia" | "Espaços";

export type Translations = {
  [key: string]: {
    code: string;
    flag: string;
    login: string;
    mural: string;
    subtitle: string;
    placeholder: string;
    discover: string;
    contact: string;
    all: string;
    modalTitle: string;
    modalMsg: string;
    categories: { [key in Category]: string };
    subCategories: { [key: string]: string };
    empty: string;
  }
}

    