"use client";

import { ArtistCard } from './artist-card';
import { Skeleton } from '@/components/ui/skeleton';
import type { Artist } from '@/lib/types';
import { useLanguage } from '@/context/language-context';

interface ArtistGridProps {
  artists: Artist[];
  isLoading: boolean;
}

export function ArtistGrid({ artists, isLoading }: ArtistGridProps) {
  const { translations, lang } = useLanguage();
  const t = translations[lang];

  if (isLoading) {
    return (
      <div id="artistGrid" className="grid grid-cols-1 md:grid-cols-[repeat(auto-fill,minmax(450px,1fr))] gap-8 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pb-20">
        {Array.from({ length: 6 }).map((_, i) => (
          <div key={i} className="flex flex-col md:flex-row bg-white rounded-2xl shadow-md overflow-hidden h-[260px]">
            <Skeleton className="w-full md:w-[38%] h-[200px] md:h-full" />
            <div className="flex-grow p-5 space-y-3">
              <Skeleton className="h-4 w-1/4" />
              <Skeleton className="h-6 w-3/4" />
              <Skeleton className="h-4 w-1/2" />
              <Skeleton className="h-10 w-full" />
              <Skeleton className="h-4 w-2/3" />
            </div>
          </div>
        ))}
      </div>
    );
  }

  if (artists.length === 0) {
    return (
        <div id="artistGrid" className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pb-20">
            <div className="text-center text-muted-foreground py-20">
                <p className="text-lg">{t.empty}</p>
            </div>
        </div>
    );
  }

  return (
    <div id="artistGrid" className="grid grid-cols-1 md:grid-cols-[repeat(auto-fill,minmax(450px,1fr))] gap-8 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pb-20">
      {artists.map((artist) => (
        <ArtistCard key={artist.id} artist={artist} />
      ))}
    </div>
  );
}
