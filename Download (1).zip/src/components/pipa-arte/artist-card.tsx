"use client";

import Image from 'next/image';
import { Instagram, Globe, Youtube, Wrench } from 'lucide-react';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
  DialogTrigger,
} from "@/components/ui/dialog";

import type { Artist } from '@/lib/types';
import { useLanguage } from '@/context/language-context';

interface ArtistCardProps {
  artist: Artist;
}

const SpotifyIcon = () => (
    <svg role="img" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 fill-current">
        <path d="M12 0C5.373 0 0 5.373 0 12s5.373 12 12 12 12-5.373 12-12S18.627 0 12 0zm5.925 17.044c-.21.322-.594.42-.916.21a.747.747 0 0 1-.21-.916c1.95-3.072 2.22-6.963.09-10.45-.22-.36-.023-.842.336-.916.36-.072.76.114.832.474 2.337 3.812 1.996 8.164-.232 11.598zM12 5.5a.5.5 0 0 1 .5.5v12a.5.5 0 0 1-1 0v-12a.5.5 0 0 1 .5-.5zm-4 3a.5.5 0 0 1 .5.5v6a.5.5 0 0 1-1 0v-6a.5.5 0 0 1 .5-.5z"/>
    </svg>
)

const socialIconMap = {
  instagram: <Instagram className="h-4 w-4" />,
  youtube: <Youtube className="h-4 w-4" />,
  spotify: <SpotifyIcon />,
  portfolio: <Globe className="h-4 w-4" />,
};

const socialColorMap = {
    instagram: 'bg-[#E1306C]',
    youtube: 'bg-[#FF0000]',
    spotify: 'bg-[#1DB954]',
    portfolio: 'bg-primary',
}

const WhatsappIcon = () => (
    <svg role="img" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 fill-current">
        <path d="M17.472 14.382c-.297-.149-.758-.372-1.03-.463-.272-.09-.47-.149-.672.149-.203.297-.78.986-1.004 1.185-.223.2-.447.224-.84.074-.393-.15-1.65-.61-3.14-1.928-.9-.78-1.482-1.758-1.65-2.053-.168-.297-.01-.447.13-.596.128-.13.297-.224.447-.373.15-.149.203-.297.297-.495.094-.198.047-.372-.025-.52-.072-.149-.672-1.62-.92-2.207-.246-.584-.494-.5-.672-.504-.178-.003-.377-.005-.574-.005-.2 0-.52.074-.792.372s-1.03 1-1.03 2.443 1.055 2.82 1.203 3.018c.149.198 2.093 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871-.118.571-.355 1.639-1.35 1.871-1.871.232-.52.232-1.03.16-1.185-.073-.15-.27-.224-.57-.372Z"/>
    </svg>
)

const SocialLink = ({ socialKey, link }: { socialKey: 'instagram' | 'portfolio' | 'youtube' | 'spotify', link: string }) => {
    const { lang, translations } = useLanguage();
    const t = translations[lang];

    const isPlaceholder = link.startsWith('(') && link.endsWith(')');

    if (isPlaceholder) {
        return (
            <Dialog>
                <DialogTrigger asChild>
                    <button title={socialKey.charAt(0).toUpperCase() + socialKey.slice(1)}
                        className={`h-8 w-8 rounded-full flex items-center justify-center text-white transition-opacity hover:opacity-80 ${socialColorMap[socialKey]}`}>
                        {socialIconMap[socialKey]}
                    </button>
                </DialogTrigger>
                <DialogContent className="sm:max-w-[425px] rounded-2xl">
                    <DialogHeader className="text-center items-center">
                        <div className="bg-blue-100 p-4 rounded-full inline-block mb-4">
                            <Wrench className="h-10 w-10 text-primary" />
                        </div>
                        <DialogTitle className="font-headline text-2xl">{t.modalTitle}</DialogTitle>
                        <DialogDescription>
                            {t.modalMsg}
                        </DialogDescription>
                    </DialogHeader>
                </DialogContent>
            </Dialog>
        );
    }
    
    const finalLink = socialKey === 'instagram' ? `https://instagram.com/${link.replace('@', '')}` : link;

    return (
        <a href={finalLink} target="_blank" rel="noopener noreferrer" title={socialKey.charAt(0).toUpperCase() + socialKey.slice(1)}
            className={`h-8 w-8 rounded-full flex items-center justify-center text-white transition-opacity hover:opacity-80 ${socialColorMap[socialKey]}`}>
            {socialIconMap[socialKey]}
        </a>
    );
};


export function ArtistCard({ artist }: ArtistCardProps) {
  const { lang, translations } = useLanguage();
  const t = translations[lang];

  const imageUrl = artist.imageUrl ?? 'https://placehold.co/400x520?text=No+Img';
  
  const socialLinks = (
    [
      {key: 'instagram', link: artist.instagramLink},
      {key: 'portfolio', link: artist.portfolioLink},
      {key: 'youtube', link: artist.youtubeLink},
      {key: 'spotify', link: artist.spotifyLink},
    ] as const
  )
    .filter(item => item.link && item.link.trim() !== '');

  return (
    <Card className="rounded-2xl overflow-hidden shadow-lg hover:shadow-xl transition-shadow duration-300 flex flex-col md:flex-row h-[500px] md:h-[260px] border-none transform hover:-translate-y-1">
      <div className="w-full md:w-[38%] h-[55%] md:h-full relative shrink-0">
        <Image
          src={imageUrl}
          alt={artist.name}
          fill
          className="object-cover"
        />
      </div>
      <CardContent className="p-5 flex flex-col flex-grow">
        {artist.category && <span className="text-xs font-bold uppercase tracking-wider text-accent mb-1">
          {t.categories[artist.category] || artist.category}
        </span>}
        <h3 className="font-headline text-2xl font-semibold text-primary leading-tight">{artist.name}</h3>
        <p className="text-sm text-muted-foreground mb-2">{artist.instagramTag}</p>
        <p className="text-sm text-gray-600 leading-snug mb-3 line-clamp-3">{artist.description}</p>
        <div className="flex flex-wrap gap-1 mb-auto">
          {artist.subCategories?.map((tag, index) => (
            <Badge key={index} variant="secondary" className="text-xs bg-gray-100 text-primary hover:bg-gray-200">
              {t.subCategories[tag] || tag}
            </Badge>
          ))}
        </div>
        <div className="border-t mt-4 pt-3 flex justify-between items-center">
          <div className="flex gap-2">
            {socialLinks.map(({ key, link }) => (
                <SocialLink key={key} socialKey={key} link={link!} />
            ))}
          </div>
          
          <Dialog>
            <DialogTrigger asChild>
                <Button size="sm" className="rounded-full bg-[#25D366] hover:bg-[#20b858] text-white transition-transform hover:scale-105 shadow-md">
                    <WhatsappIcon />
                    <span className="ml-1.5">{t.contact}</span>
                </Button>
            </DialogTrigger>
            <DialogContent className="sm:max-w-[425px] rounded-2xl">
                <DialogHeader className="text-center items-center">
                    <div className="bg-blue-100 p-4 rounded-full inline-block mb-4">
                        <Wrench className="h-10 w-10 text-primary" />
                    </div>
                  <DialogTitle className="font-headline text-2xl">{t.modalTitle}</DialogTitle>
                  <DialogDescription>
                    {t.modalMsg}
                  </DialogDescription>
                </DialogHeader>
            </DialogContent>
          </Dialog>

        </div>
      </CardContent>
    </Card>
  );
}
