"use client";

import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
  DialogTrigger,
} from "@/components/ui/dialog";
import { Wrench } from "lucide-react";
import { useLanguage } from "@/context/language-context";

export function LoginModal({ children }: { children: React.ReactNode }) {
  const { translations, lang } = useLanguage();
  const t = translations[lang];

  return (
    <Dialog>
      <DialogTrigger asChild>
        {children}
      </DialogTrigger>
      <DialogContent className="sm:max-w-[425px] rounded-2xl">
        <DialogHeader className="text-center items-center">
            <div className="bg-blue-100 p-4 rounded-full inline-block mb-4">
                <Wrench className="h-10 w-10 text-primary" />
            </div>
          <DialogTitle className="font-headline text-2xl">{t.modalTitle}</DialogTitle>
          <DialogDescription>
            {t.modalMsg}
          </DialogDescription>
        </DialogHeader>
      </DialogContent>
    </Dialog>
  );
}
