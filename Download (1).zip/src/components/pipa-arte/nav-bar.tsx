"use client";

import { UserCircle } from 'lucide-react';
import { LangSwitcher } from './lang-switcher';
import { LoginModal } from './login-modal';
import { Button } from '@/components/ui/button';
import { useLanguage } from '@/context/language-context';

export function NavBar() {
  const { translations, lang } = useLanguage();
  const t = translations[lang];

  return (
    <nav className="absolute top-0 left-0 w-full flex justify-between items-center p-4 md:p-6 z-20">
      <LangSwitcher />
      <div className="flex items-center gap-4">
        <LoginModal>
          <Button
            variant="ghost"
            className="bg-white/25 border border-white/50 text-white rounded-full h-auto py-2 px-4 backdrop-blur-sm hover:bg-white hover:text-primary transition-all duration-300"
          >
            <UserCircle className="h-5 w-5 mr-0 md:mr-2" />
            <span className="hidden md:inline">{t.login}</span>
          </Button>
        </LoginModal>
      </div>
    </nav>
  );
}
