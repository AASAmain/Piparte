"use client";

import { useState, useMemo, useEffect } from 'react';
import { artistsData, categories } from '@/data/artists';
import { Artist, Category } from '@/lib/types';

import { Header } from './header';
import { Controls } from './controls';
import { ArtistGrid } from './artist-grid';
import { useToast } from "@/hooks/use-toast"


export function ArtistPage() {
  const [searchQuery, setSearchQuery] = useState('');
  const [currentCategory, setCurrentCategory] = useState<Category | 'all'>('all');
  const { toast } = useToast()
  const [allArtists, setAllArtists] = useState<Artist[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    // Fisher-Yates shuffle algorithm to randomize the artists array
    const shuffleArray = (array: Artist[]) => {
      let currentIndex = array.length, randomIndex;
      const newArray = [...array]; // Create a copy
      // While there remain elements to shuffle.
      while (currentIndex !== 0) {
        // Pick a remaining element.
        randomIndex = Math.floor(Math.random() * currentIndex);
        currentIndex--;
        // And swap it with the current element.
        [newArray[currentIndex], newArray[randomIndex]] = [
          newArray[randomIndex], newArray[currentIndex]];
      }
      return newArray;
    };

    // Simulate fetching data and shuffle it
    const timer = setTimeout(() => {
      setAllArtists(shuffleArray(artistsData));
      setIsLoading(false);
    }, 500); // Simulating network delay

    return () => clearTimeout(timer);
  }, []);

  const filteredArtists = useMemo(() => {
    if (!allArtists) return [];
    
    return allArtists.filter(artist => {
        const matchesCategory = currentCategory === 'all' || artist.category === currentCategory;
        
        const query = searchQuery.toLowerCase();
        const matchesSearch = 
            artist.name.toLowerCase().includes(query) || 
            (artist.instagramTag && artist.instagramTag.toLowerCase().includes(query)) ||
            (artist.subCategories && artist.subCategories.some(tag => tag.toLowerCase().includes(query))) ||
            (artist.category && artist.category.toLowerCase().includes(query)) ||
            (artist.description && artist.description.toLowerCase().includes(query));

        return matchesCategory && matchesSearch;
    });
  }, [allArtists, searchQuery, currentCategory]);

  const handleDiscoverRandom = () => {
    if (!allArtists || allArtists.length === 0) return;
    const randomArtist = allArtists[Math.floor(Math.random() * allArtists.length)];
    
    if(randomArtist.category) {
        setCurrentCategory(randomArtist.category);
    }
    setSearchQuery(randomArtist.name); 
    
    document.getElementById('artistGrid')?.scrollIntoView({ behavior: 'smooth' });

    toast({
        title: "Artista em Destaque ✨",
        description: `Confira o trabalho de ${randomArtist.name}!`,
    })
  };

  return (
    <div className="flex flex-col min-h-screen">
      <Header />
      <main className="w-full">
        <Controls
          searchQuery={searchQuery}
          setSearchQuery={setSearchQuery}
          currentCategory={currentCategory}
          setCurrentCategory={setCurrentCategory}
          categories={categories}
          onDiscoverRandom={handleDiscoverRandom}
        />
        <ArtistGrid artists={filteredArtists} isLoading={isLoading} />
      </main>
    </div>
  );
}
