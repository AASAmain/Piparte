"use client";

import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Button } from "@/components/ui/button";
import { ChevronDown } from "lucide-react";
import { useLanguage } from "@/context/language-context";

export function LangSwitcher() {
  const { lang, setLang, translations } = useLanguage();
  const t = translations[lang];

  const languages = [
    { code: 'pt', label: 'BR', flag: '🇧🇷' },
    { code: 'en', label: 'EN', flag: '🇺🇸' },
    { code: 'es', label: 'ES', flag: '🇪🇸' },
    { code: 'it', label: 'IT', flag: '🇮🇹' },
  ];

  return (
    <DropdownMenu>
      <DropdownMenuTrigger asChild>
        <Button
          variant="ghost"
          className="bg-white/25 border border-white/50 text-white rounded-full h-auto py-2 px-4 backdrop-blur-sm hover:bg-white/40 transition-all duration-300 min-w-[100px] justify-between"
        >
          <span>{t.flag} {t.code}</span>
          <ChevronDown className="h-4 w-4" />
        </Button>
      </DropdownMenuTrigger>
      <DropdownMenuContent className="bg-white rounded-xl shadow-lg border-none mt-2 w-[100px]">
        {languages.map((language) => (
          <DropdownMenuItem
            key={language.code}
            className="cursor-pointer text-primary hover:bg-gray-100 rounded-lg"
            onClick={() => setLang(language.code)}
          >
            <span className="mr-2">{language.flag}</span>
            {language.label}
          </DropdownMenuItem>
        ))}
      </DropdownMenuContent>
    </DropdownMenu>
  );
}
