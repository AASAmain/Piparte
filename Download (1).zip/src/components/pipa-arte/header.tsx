"use client";

import Image from 'next/image';
import { NavBar } from './nav-bar';
import { useLanguage } from '@/context/language-context';

export function Header() {
  const { translations, lang } = useLanguage();
  const t = translations[lang];
  
  return (
    <div className="relative">
      <NavBar />
      <header className="bg-[linear-gradient(135deg,_#3D5A80,_#4ca1af)] text-white pt-14 pb-20 text-center relative overflow-hidden">
        <div className="relative z-10 px-4">
          <Image
            src="https://i.ibb.co/qLnZ5LGd/Abstract-Background-Design-Dec-27-2025.png"
            alt="PIPARTE Logo"
            width={220}
            height={70}
            className="mx-auto mb-2 w-[70%] max-w-[220px] h-auto block filter drop-shadow-lg"
            priority
          />
          <p className="font-headline text-xl md:text-2xl font-normal italic opacity-95 max-w-2xl mx-auto subtitle-float text-shadow-md">
            {t.subtitle}
          </p>
        </div>
        
        <svg className="waves" xmlns="http://www.w3.org/2000/svg" xmlnsXlink="http://www.w3.org/1999/xlink"
        viewBox="0 24 150 28" preserveAspectRatio="none" shapeRendering="auto">
            <defs>
                <path id="gentle-wave" d="M-160 44c30 0 58-18 88-18s 58 18 88 18 58-18 88-18 58 18 88 18 v44h-352z" />
            </defs>
            <g className="parallax">
                <use xlinkHref="#gentle-wave" x="48" y="0" className="fill-background/70" />
                <use xlinkHref="#gentle-wave" x="48" y="3" className="fill-background/50" />
                <use xlinkHref="#gentle-wave" x="48" y="5" className="fill-background/30" />
                <use xlinkHref="#gentle-wave" x="48" y="7" className="fill-background" />
            </g>
        </svg>
      </header>
    </div>
  );
}
