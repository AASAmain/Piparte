"use client";

import Link from 'next/link';
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Dice5, Brush } from "lucide-react";
import type { Category } from "@/lib/types";
import { useLanguage } from "@/context/language-context";

interface ControlsProps {
  searchQuery: string;
  setSearchQuery: (query: string) => void;
  currentCategory: Category | 'all';
  setCurrentCategory: (category: Category | 'all') => void;
  categories: Category[];
  onDiscoverRandom: () => void;
}

export function Controls({
  searchQuery,
  setSearchQuery,
  currentCategory,
  setCurrentCategory,
  categories,
  onDiscoverRandom,
}: ControlsProps) {
  const { translations, lang } = useLanguage();
  const t = translations[lang];

  return (
    <div className="max-w-7xl mx-auto -mt-8 px-4 sm:px-6 lg:px-8 pb-10 flex flex-col items-center gap-5 relative z-10">
      <div className="flex flex-col sm:flex-row gap-2.5 w-full max-w-2xl">
        <Input
          type="text"
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
          placeholder={t.placeholder}
          className="flex-grow h-14 px-6 rounded-full text-base shadow-lg focus:ring-2 focus:ring-accent"
        />
        <Button
          onClick={onDiscoverRandom}
          className="bg-accent text-accent-foreground h-14 px-6 rounded-full font-semibold shadow-lg hover:bg-accent/90 transition-transform hover:scale-105"
        >
          <Dice5 className="h-6 w-6 mr-2" />
          <span>{t.discover}</span>
        </Button>
        <Link href="/mural">
            <Button
                asChild
                className="bg-primary text-primary-foreground h-14 px-6 rounded-full font-semibold shadow-lg hover:bg-primary/90 transition-transform hover:scale-105 w-full sm:w-auto"
            >
                <div>
                    <Brush className="h-6 w-6 mr-2" />
                    <span>{t.mural}</span>
                </div>
            </Button>
        </Link>
      </div>
      <div className="flex flex-wrap gap-2.5 justify-center">
        <Button
          variant={currentCategory === 'all' ? 'default' : 'secondary'}
          onClick={() => setCurrentCategory('all')}
          className={`rounded-full transition-all duration-300 ${currentCategory === 'all' ? 'bg-primary text-primary-foreground' : 'bg-white text-primary hover:bg-gray-100'}`}
        >
          {t.all}
        </Button>
        {categories.map((cat) => (
          <Button
            key={cat}
            variant={currentCategory === cat ? 'default' : 'secondary'}
            onClick={() => setCurrentCategory(cat)}
            className={`rounded-full transition-all duration-300 ${currentCategory === cat ? 'bg-primary text-primary-foreground' : 'bg-white text-primary hover:bg-gray-100'}`}
          >
            {t.categories[cat] || cat}
          </Button>
        ))}
      </div>
    </div>
  );
}
