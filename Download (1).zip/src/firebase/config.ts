export const firebaseConfig = {
  "projectId": "studio-4024984642-402c0",
  "appId": "1:754009583186:web:b573a681888af7d91ab98b",
  "apiKey": "AIzaSyBEnY6Hqibw8eD62Qwc1n8KnObeflFJIU0",
  "authDomain": "studio-4024984642-402c0.firebaseapp.com",
  "measurementId": "",
  "messagingSenderId": "754009583186"
};
